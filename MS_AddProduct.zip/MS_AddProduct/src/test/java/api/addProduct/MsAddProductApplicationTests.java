package api.addProduct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsAddProductApplicationTests {

	@Test
	void contextLoads() {
	}

}
