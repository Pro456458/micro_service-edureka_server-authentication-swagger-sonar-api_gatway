package api.addProduct.dto;

public class AddProductResponseDto {

}
