package api.addProduct.service;

public interface AddProductService {

}
