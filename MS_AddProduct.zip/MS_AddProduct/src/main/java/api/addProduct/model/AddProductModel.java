package api.addProduct.model;

public class AddProductModel {

}
