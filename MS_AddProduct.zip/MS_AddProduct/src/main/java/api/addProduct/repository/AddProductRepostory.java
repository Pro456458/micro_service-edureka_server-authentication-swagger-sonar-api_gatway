package api.addProduct.repository;

public class AddProductRepostory {

}
