/**
 * 
 */
package api.buyProduct.model;

/**
 * @author Administrator
 *
 */
public interface AvailableProductQuantity {
	
	int getQuantity();
	int getProductId();

}
