/**
 * 
 */
package api.buyProduct.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * @author Administrator
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity(name = "product_master")
public class ProductMas {
	
	@Id
	@Column(name = "product_id")
	private int productId;
	
	@Column(name = "product_name")
    private String productName=null;
	
	@Column(name = "procudt_category")
    private String procudtCategory=null;
	
	@Column(name = "product_price")
    private double productPrice;
	
	@Column(name = "quantity")
    private int quantity;
	
	@Column(name = "category_id")
    private int categoryId;
    
    @ManyToOne
    @JoinColumn(name = "category_id", referencedColumnName = "category_id", insertable = false, updatable = false)
    private CategoryMas categoryMas;
    
 
    

}
