/**
 * 
 */
package api.buyProduct.model;

/**
 * @author Administrator
 *
 */
/** 
 * Interface-based Projections 
 **/
public interface TotalPriceOnly {
	double getTotalPrice();
}
