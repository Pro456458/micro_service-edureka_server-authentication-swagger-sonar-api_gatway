/**
 * 
 */
package api.buyProduct.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author Administrator
 *
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity(name = "orders")
public class OrderMas {
	
	@Id
//	@SequenceGenerator(name="orders_order_id_seq",sequenceName="orders_order_id_seq", allocationSize=1)
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="orders_order_id_seq")
	
	@GeneratedValue
	@Column(name = "order_id")
    private int orderId;
	@Column(name = "date_time")
    private int dateTime;
	@Column(name = "total_price")
    private double totalPrice;
    @Column(name = "user_id")
    private int userId;

    @OneToMany(targetEntity = OrderDetailMas.class, cascade = CascadeType.ALL)
    @JoinColumn(name = "order_id", referencedColumnName = "order_id")
    private List<OrderDetailMas> orderDetail;
    
    

    

}
