/**
 * 
 */
package api.buyProduct.service;

import java.util.List;


import api.buyProduct.dto.BuyProductRequestDto;
import api.buyProduct.dto.BuyProductResponseDto;

/**
 * @author Administrator
 *
 */
public interface BuyProductService {

	List<BuyProductResponseDto> placeOrder(BuyProductRequestDto buyProductRequestDto) throws Exception;

}
