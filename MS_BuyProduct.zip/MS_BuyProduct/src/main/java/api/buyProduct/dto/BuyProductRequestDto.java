/**
 * 
 */
package api.buyProduct.dto;

import java.util.List;

/**
 * @author Administrator
 *
 */
public class BuyProductRequestDto {
	
	private int user_id;
    private String account_no=null;
    
    private List<ProductDto> productList=null;
    
    

	public BuyProductRequestDto(int user_id, String account_no, List<ProductDto> productList) {
		super();
		this.user_id = user_id;
		this.account_no = account_no;
		this.productList = productList;
	}


	public BuyProductRequestDto() {
		super();		
	}


	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	
	
	public String getAccount_no() {
		return account_no;
	}


	public void setAccount_no(String account_no) {
		this.account_no = account_no;
	}


	public List<ProductDto> getProductList() {
		return productList;
	}


	public void setProductList(List<ProductDto> productList) {
		this.productList = productList;
	}


	@Override
	public String toString() {
		return "BuyProductRequestDto [user_id=" + user_id + ", account_no=" + account_no + ", productList="
				+ productList + "]";
	}




	
    
    
    
}
