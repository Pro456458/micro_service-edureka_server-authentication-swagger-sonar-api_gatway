package api.buyProduct.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import api.buyProduct.model.AvailableProductQuantity;
import api.buyProduct.model.ProductMas;
import api.buyProduct.model.ProductPriceOnly;

public interface SearchProductRepository extends JpaRepository<ProductMas, Integer>{

	ProductPriceOnly findOneByProductId(int productId);
	List<AvailableProductQuantity> findAllByProductIdIn(List<Integer> productIdList);

}
