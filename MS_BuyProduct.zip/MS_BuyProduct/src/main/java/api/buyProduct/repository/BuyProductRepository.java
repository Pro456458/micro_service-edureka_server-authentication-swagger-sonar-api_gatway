/**
 * 
 */
package api.buyProduct.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import api.buyProduct.model.OrderMas;



/**
 * @author Administrator
 *
 */
public interface BuyProductRepository extends JpaRepository<OrderMas, Integer>{
	
//	@Query(value = "SELECT p FROM product_master p WHERE p.product_name =:product_name")
//	public List<ProductMas> searchProductByProductName(@Param("product_name") String product_name);
	
//	public Collection<QuantityOnly> findByProductList(int order_id);
	
	

}

