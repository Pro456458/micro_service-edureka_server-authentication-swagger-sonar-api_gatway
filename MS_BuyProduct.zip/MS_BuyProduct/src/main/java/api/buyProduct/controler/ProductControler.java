/**
 * 
 */
package api.buyProduct.controler;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import api.buyProduct.dto.BuyProductRequestDto;
import api.buyProduct.dto.BuyProductResponseDto;
import api.buyProduct.exception.ProductNotAvailable;
import api.buyProduct.service.BuyProductService;



/**
 * @author Administrator
 *
 */
@RestController
public class ProductControler {


	@Autowired
	BuyProductService buyProductService=null;



	@RequestMapping(path = "/api/product/buyProduct", method = RequestMethod.POST)
	private ResponseEntity<List<BuyProductResponseDto>> buyProduct(@RequestBody BuyProductRequestDto buyProductRequestDto) {

		try {
			return ResponseEntity.ok(buyProductService.placeOrder(buyProductRequestDto));
		} catch (Exception e) {
			System.out.println(e.toString());
			throw new ProductNotAvailable(e.toString()) ;
		}
		
		


	}
	
 

}
