package api.buyProduct.dto;

import java.util.List;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class BuyProductResponseDto {
	
	private int userId;
    private int accountNo;
    private int order_id;
    private double totalPrice;
    private String dateTime;
    
    private List<OrderDetailDto> productOrderDetailList=null;



	
    
}
