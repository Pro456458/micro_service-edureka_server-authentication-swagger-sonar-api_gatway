package api.buyProduct.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class OrderDetailDto {
	
	  private int price;
	  private int quantity;
	  private int productId;
	  private int orderDetailsId;
	  private String productName;
}
