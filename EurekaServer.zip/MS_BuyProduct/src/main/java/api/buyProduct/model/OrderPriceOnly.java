/**
 * 
 */
package api.buyProduct.model;

/**
 * @author Administrator
 *
 */
public interface OrderPriceOnly {
	
	double getPrice();

}
