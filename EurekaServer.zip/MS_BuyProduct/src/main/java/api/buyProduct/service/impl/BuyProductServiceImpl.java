/**
 * 
 */
package api.buyProduct.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import api.buyProduct.dto.BuyProductRequestDto;
import api.buyProduct.dto.BuyProductResponseDto;
import api.buyProduct.dto.OrderDetailDto;
import api.buyProduct.dto.ProductDto;
import api.buyProduct.dto.RemoveProductFromCartRequestDto;
import api.buyProduct.model.AvailableProductQuantity;
import api.buyProduct.model.OrderDetailMas;
import api.buyProduct.model.OrderMas;
import api.buyProduct.model.ProductPriceOnly;
import api.buyProduct.repository.BuyProductRepository;
import api.buyProduct.repository.SearchProductRepository;
import api.buyProduct.service.BuyProductService;
import api.buyProduct.service.RemoveProductFromCartService;

/**
 * @author Administrator
 *
 */
@Service
public class BuyProductServiceImpl implements BuyProductService {
	
	@Autowired
	SearchProductRepository searchProductRepository;
	
	@Autowired
	BuyProductRepository buyProductRepository;
	
	@Autowired
	RemoveProductFromCartService removeProductFromCartService;
	
	
	
	@Override
	public List<BuyProductResponseDto> placeOrder(BuyProductRequestDto buyProductRequestDto) throws Exception {
		
		//throws IllegalArgumentException if requested quantity of product is exceed to available quantity
		checkQuantityAvailableForProduct( buyProductRequestDto.getProductList());
		
//		if(!checkQuantityAvailableForProduct( buyProductRequestDto.getProductList()) )
//			throw new IllegalArgumentException("Quantity Not Available");
		 
		if(!checkUserAccount_MinimumBalanceToPlaceOrder( buyProductRequestDto.getAccount_no(), getTotalPriceOfOrder(buyProductRequestDto.getProductList()))) 
			throw new IllegalArgumentException("Minimum balance not avilable in user account for place order.");
		
		OrderMas orderMas=getOrder(buyProductRequestDto);
		
		OrderMas response=buyProductRepository.save(orderMas);
		
		
		removeProductFronCart(orderMas);
		
		
		return prepareBuyProductResponse(response, buyProductRequestDto);
	}
	
	private void removeProductFronCart(OrderMas orderMas) {
		
		RemoveProductFromCartRequestDto dto=new RemoveProductFromCartRequestDto();
		
		dto.setUserId(String.valueOf(orderMas.getUserId()));
		dto.setProductId(orderMas.getOrderDetail().get(0).getProductId());
		
		removeProductFromCartService.removeProduct(dto);
		
	}

	private List<BuyProductResponseDto> prepareBuyProductResponse(OrderMas responseOrderBean,BuyProductRequestDto buyProductRequestDto){
		
		BuyProductResponseDto buyProductResponseDto=new BuyProductResponseDto();
		
		
		buyProductResponseDto.setAccountNo(Integer.valueOf(buyProductRequestDto.getAccount_no()));
		buyProductResponseDto.setDateTime(String.valueOf(responseOrderBean.getDateTime()));
		buyProductResponseDto.setOrder_id(responseOrderBean.getOrderId());
		buyProductResponseDto.setTotalPrice(responseOrderBean.getTotalPrice());		
		buyProductResponseDto.setUserId(responseOrderBean.getUserId());
		
		buyProductResponseDto.setProductOrderDetailList(getOrderDetailsResponse(responseOrderBean.getOrderDetail()));
		
		
		List<BuyProductResponseDto> responseList=new ArrayList<BuyProductResponseDto>();
		responseList.add(buyProductResponseDto);
		
		return responseList;
		
	}
	private List<OrderDetailDto> getOrderDetailsResponse(List<OrderDetailMas> orderDetail) {
		List<OrderDetailDto> orderDetailDtoList =new ArrayList<OrderDetailDto>();
		orderDetail.forEach( orderDetailMas->{
					OrderDetailDto orderDetailDto=new OrderDetailDto();
					orderDetailDto.setOrderDetailsId(orderDetailMas.getOrder_details_id());
					orderDetailDto.setProductId(orderDetailMas.getProductId());
					orderDetailDto.setQuantity(orderDetailMas.getQuantity());
					orderDetailDto.setPrice(orderDetailMas.getPrice());
					ProductPriceOnly productPrice =searchProductRepository.findOneByProductId(orderDetailMas.getProductId());  
					orderDetailDto.setProductName(productPrice.getProductName());
					orderDetailDtoList.add(orderDetailDto);
		}
		);
		
		/***
		 *  
		 * set hard code detail for testing 
		 * 
		 * ***/
		
		
		
		
		return orderDetailDtoList;
	}

	private OrderMas getOrder(BuyProductRequestDto buyProductRequestDto) {
		
		OrderMas orderMas=new OrderMas();
		orderMas.setUserId(buyProductRequestDto.getUser_id());
		orderMas.setDateTime(1082021);
		orderMas.setTotalPrice(getTotalPriceOfOrder(buyProductRequestDto.getProductList()));
		orderMas.setOrderDetail(getOrderDetail(buyProductRequestDto));
		
		/***
		 *  
		 * set hard code detail for testing 
		 * 
		 * ***/
		
		
		
		
		return orderMas;
	}


	private List<OrderDetailMas> getOrderDetail(BuyProductRequestDto buyProductRequestDto) {
		// iterate buyProductRequestDto   
		//get price on basis of product id, use method findOneByProductId 
		// 
		List<OrderDetailMas> orderDetailList =new ArrayList<OrderDetailMas>();

		buyProductRequestDto.getProductList().forEach(
				productDto ->{ 
					OrderDetailMas orderDetailMas=new OrderDetailMas();
					ProductPriceOnly productPrice =searchProductRepository.findOneByProductId(productDto.getProduct_id());  
					orderDetailMas.setPrice((int)productPrice.getProductPrice());
					orderDetailMas.setProductId(productDto.getProduct_id());
					orderDetailMas.setQuantity(productDto.getQuantity());
					orderDetailList.add(orderDetailMas);
				}
				);
		
		
	
		
		return orderDetailList;
	}


	private boolean checkUserAccount_MinimumBalanceToPlaceOrder(String account_no, double totalPriceOfOrder) {
		
		//get the amount from user bank and with account_no
		//compare amount with totalPriceOfOrder
		
		return true;
	}


	private double getTotalPriceOfOrder(List<ProductDto> productList) {
		
		double sumOfTotaPrice=0l;
		
		List<Integer> productIdList=new ArrayList<Integer>();
		
		productList.forEach( productDto -> productIdList.add(productDto.getProduct_id()));
		
		/** via Stream API with lambda **/
		sumOfTotaPrice=productIdList.stream().map( product_id ->
		  searchProductRepository.findOneByProductId(product_id) ).mapToDouble(
				  ProductPriceOnly -> ProductPriceOnly.getProductPrice()).sum();
				  		
		/** via iterator **/		
/*		
		for (Iterator<Integer> iterator = productIdList.iterator(); iterator.hasNext();) {
			Integer product_id = (Integer) iterator.next();
			
			//searchProductRepository.findOneByProductId(product_id).forEach( e-> System.out.println( e.getProductPrice()));
			
			ProductPriceOnly ProductPriceOnly=searchProductRepository.findOneByProductId(product_id);
			sumOfTotaPrice+=ProductPriceOnly.getProductPrice();
			System.out.println(sumOfTotaPrice);
			
		}
*/			
		
		
//		List<ProductPriceOnly> priceList1 = null;
		
//		productIdList.stream().forEach( product_id ->
//		  priceList1.add(searchProductRepository.findOneByProductId(product_id)) );
		
//		List<ProductPriceOnly> priceList=productIdList.stream().map( product_id ->
//		  searchProductRepository.findOneByProductId(product_id) ).collect(Collectors.toList());
		
		
		//sumOfTotaPrice=priceList.stream().mapToDouble( ProductPriceOnly -> ProductPriceOnly.getPrice()).sum();		
		//priceList.forEach( ProductPriceOnly-> sumOfTotaPrice+=ProductPriceOnly.getPrice());
		System.out.print(sumOfTotaPrice);
		return sumOfTotaPrice;
		
	}


	private boolean checkQuantityAvailableForProduct(List<ProductDto> productList) {
		
		
		List<Integer> productIdList=new ArrayList<Integer>();
		
		productList.forEach( productDto -> productIdList.add(productDto.getProduct_id()));
		
		List<AvailableProductQuantity> availableProductQuantityList=searchProductRepository.findAllByProductIdIn(productIdList);

		Map<Integer,Boolean> availableProductQuantityMap=getAvailableProductQuantityMap(productList,availableProductQuantityList);
		
		availableProductQuantityMap.forEach( (productId,availabilityStatus) -> 
			{
				if(!availabilityStatus)
					throw new IllegalArgumentException("Requested Quantity Not Available For Product "+productId); 
			}
		);
		 
		return true;
	}
	
	
	/** this method return Map Of <product id>  and <availability status> after comparing availability quantity **/
	private Map<Integer,Boolean> getAvailableProductQuantityMap(List<ProductDto> productList,List<AvailableProductQuantity> availableProductQuantityList) {
		
		
		Map<Integer,Boolean> availableProductQuantityMap=new HashMap<>();
		
	
		/******** via for loop *********/		
		/*			
		for(ProductDto one : productList) {
		    for(AvailableProductQuantity two : availableProductQuantityList) {
		    	
		    	if(one.getProduct_id()==two.getProductId()) {
		    		System.out.println(one.toString()+",Available Stock == "+two.getProductId()+", "+two.getQuantity());
		    		availableProductQuantityMap.put(one.getProduct_id(), one.getQuantity()<=two.getQuantity());
		    	}
		        
		        
		    }
		}
		 */
		
		/******** via for each with lambda*********/
		
		productList.forEach(  requestProductQuantity -> availableProductQuantityList.forEach(
				availableProductQuantity ->{				
					if(requestProductQuantity.getProduct_id()==availableProductQuantity.getProductId())
						availableProductQuantityMap.put(requestProductQuantity.getProduct_id() , requestProductQuantity.getQuantity()<=availableProductQuantity.getQuantity());
				}
				) );
		

		return availableProductQuantityMap;
		
	}
	

	private int getTotalQuantityFromProductList(List<ProductDto> productList) {
		
		int sumOfTotaQuantity=0;
		
		sumOfTotaQuantity=productList.stream().mapToInt( productDto -> productDto.getQuantity()).sum();
		
		//productList.forEach( productDto ->  sumOfTotaQuantity+=productDto.getQuantity() );
		
		return sumOfTotaQuantity;
	}

}
