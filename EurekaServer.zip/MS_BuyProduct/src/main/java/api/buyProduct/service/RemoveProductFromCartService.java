package api.buyProduct.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import api.buyProduct.dto.RemoveProductFromCartRequestDto;

@FeignClient(url = "http://localhost:5050/addProduct",value = "cartService")

public interface RemoveProductFromCartService {

	@RequestMapping(method = RequestMethod.DELETE)
	public ResponseEntity<String> removeProduct(@RequestBody RemoveProductFromCartRequestDto removeProductFromCartRequestDto);
		
	
}
