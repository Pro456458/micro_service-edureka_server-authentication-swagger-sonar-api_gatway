package api.searchProduct.exceptionHandler;




import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import api.searchProduct.exception.AuthorizationException;
import api.searchProduct.exception.DuplicateEntryException;
import api.searchProduct.exception.ObjectNotFoundException;
import api.searchProduct.exception.ProductNotAvailable;

@ControllerAdvice
public class ResourceExceptionHandler {


	
	  @ExceptionHandler(ProductNotAvailable.class)
	    public ResponseEntity<StandardError> productHasAlreadyBeenSold(ProductNotAvailable e, HttpServletRequest request) {

	        StandardError err = new StandardError(System.currentTimeMillis(), HttpStatus.BAD_REQUEST.value(),
	                "Product Not Available", e.getMessage(), request.getRequestURI());

	        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(err);
	    }
	  
	  @ExceptionHandler(ObjectNotFoundException.class)
	    public ResponseEntity<StandardError> objectNotFound(ObjectNotFoundException e, HttpServletRequest request) {

	        StandardError err = new StandardError(System.currentTimeMillis(), HttpStatus.NOT_FOUND.value(),
	                "Not found", e.getMessage(), request.getRequestURI());

	        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(err);
	    }
	  
	  @ExceptionHandler(DuplicateEntryException.class)
	    public ResponseEntity<StandardError> duplicateEntry(DuplicateEntryException e, HttpServletRequest request) {

	        StandardError err = new StandardError(System.currentTimeMillis(), HttpStatus.BAD_REQUEST.value(),
	                "Duplicate entry", e.getMessage(), request.getRequestURI());

	        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(err);
	    }
	  

	  
	  @ExceptionHandler(AuthorizationException.class)
	    public ResponseEntity<StandardError> authorization(AuthorizationException e, HttpServletRequest request) {

	        StandardError err = new StandardError(System.currentTimeMillis(), HttpStatus.FORBIDDEN.value(),
	                "Authorization", e.getMessage(), request.getRequestURI());

	        return ResponseEntity.status(HttpStatus.FORBIDDEN).body(err);
	    }
	 

}
