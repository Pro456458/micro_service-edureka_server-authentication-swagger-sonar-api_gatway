/**
 * 
 */
package api.searchProduct.service;

import java.util.List;

import api.searchProduct.dto.SearchProductRequestDto;
import api.searchProduct.dto.SearchProductResponseDto;
import api.searchProduct.model.ProductMas;

/**
 * @author Administrator
 *
 */
public interface SearchProductService {

	public List<ProductMas> searchProduct() throws Exception;
	public List<ProductMas> searchProduct(int product_id) ;
	
	public List<SearchProductResponseDto> searchProductByProductNameOrProductType(SearchProductRequestDto searchProductRequestBean);
	
}
