/**
 * 
 */
package api.searchProduct.model;

/**
 * @author Administrator
 *
 */
public interface AvailableProductQuantity {
	
	int getQuantity();
	int getProductId();

}
