/**
 * 
 */
package api.searchProduct.model;

/**
 * @author Administrator
 *
 */
public interface ProductPriceOnly {
	public double getProductPrice();
	public String  getProductName();
}
