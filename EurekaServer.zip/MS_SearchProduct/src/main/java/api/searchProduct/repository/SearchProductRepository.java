/**
 * 
 */
package api.searchProduct.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import api.searchProduct.model.ProductMas;
import api.searchProduct.model.ProductPriceOnly;
import api.searchProduct.model.AvailableProductQuantity;

/**
 * @author Administrator
 *
 */

public interface SearchProductRepository extends JpaRepository<ProductMas, Integer>{
	
	
	

	@Query(value = "SELECT p FROM product_master p WHERE p.productName =:product_name")
	public List<ProductMas> searchProductByProductName(@Param("product_name") String product_name);
	
	
	@Query(value = "SELECT  pm FROM  product_master pm "
			+ "INNER JOIN pm.categoryMas cm "
			+ "WHERE "
			+ "cm.category_name =:category_name")
	public List<ProductMas> searchProductByCategoryName(@Param("category_name") String category_id);
	
	
//	@Query(value = "SELECT pm.productPrice FROM product_master pm WHERE pm.productId =:product_id")
//	public List<ProductPriceOnly> searchProductPriceByProductId(@Param("product_id") Integer product_id);
	
	public ProductPriceOnly findOneByProductId(Integer product_id);
	
	/** 
	 * select pm.quantity, pm.product_id from product_master productmas pm where pm.product_id in (?) 
	 **/ 
	public List<AvailableProductQuantity> findAllByProductIdIn(List<Integer> productIdList);
	
	
	
	
	

}
