/**
 * 
 */
package api.searchProduct.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * @author Administrator
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class SearchProductResponseDto {
	private String productName=null;
	private String categoryName=null;
	
	
		

}
