/**
 * 
 */
package api.addProduct.model;

/**
 * @author Administrator
 *
 */
public interface ProductPriceOnly {
	public double getProductPrice();
	public String  getProductName();
}
