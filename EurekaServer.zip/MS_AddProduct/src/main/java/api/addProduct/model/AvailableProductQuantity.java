/**
 * 
 */
package api.addProduct.model;

/**
 * @author Administrator
 *
 */
public interface AvailableProductQuantity {
	
	int getQuantity();
	int getProductId();

}
