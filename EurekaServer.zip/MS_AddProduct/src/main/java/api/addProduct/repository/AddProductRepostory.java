package api.addProduct.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import api.addProduct.model.UserCartMas;


@Repository
public interface AddProductRepostory extends JpaRepository<UserCartMas, Integer>{
	
	public UserCartMas findByUserIdAndProductId(String userId,int productId);
	
	

}
