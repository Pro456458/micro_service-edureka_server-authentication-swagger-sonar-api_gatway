package api.addProduct.dto;

public class RemoveProductResponseDto {
	
	private boolean status;

}
