package api.addProduct.controler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import api.addProduct.dto.AddProductRequestDto;
import api.addProduct.dto.AddProductResponseDto;
import api.addProduct.service.AddProductService;


@RestController
public class AddProductControler {
	
	



	@Autowired
	AddProductService addProductService;


	@RequestMapping(path = "/api/product/addcart/{product_id}", method = RequestMethod.POST)
	private ResponseEntity<AddProductResponseDto> addProduct(@RequestBody AddProductRequestDto addProductRequestDto) {
		
			return ResponseEntity.ok(addProductService.addProduct(addProductRequestDto));

	}

	
 

	

}
