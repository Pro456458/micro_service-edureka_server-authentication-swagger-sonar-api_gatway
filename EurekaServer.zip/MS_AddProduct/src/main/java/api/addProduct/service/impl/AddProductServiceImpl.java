package api.addProduct.service.impl;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import api.addProduct.dto.AddProductRequestDto;
import api.addProduct.dto.AddProductResponseDto;
import api.addProduct.dto.RemoveProductFromCartRequestDto;
import api.addProduct.model.UserCartMas;
import api.addProduct.repository.AddProductRepostory;
import api.addProduct.service.AddProductService;

@Service
public class AddProductServiceImpl implements AddProductService{
	
	@Autowired
	AddProductRepostory addProductRepostory;
	
	@Override
	public AddProductResponseDto addProduct(AddProductRequestDto addProductRequestDto) {
		
		UserCartMas userCartMas=new UserCartMas();
		
		
		BeanUtils.copyProperties(addProductRequestDto,userCartMas);
		
		UserCartMas userCartMasResponse=addProductRepostory.save(userCartMas);
		
		
		return prepareResponse(userCartMasResponse);
		
		
		
	}

	private AddProductResponseDto prepareResponse(UserCartMas userCartMasResponse) {
		
		if(userCartMasResponse.getCartId()!=0)		
			return new AddProductResponseDto("Product added into cart...!!");
		else
			return new AddProductResponseDto("Product not added into cart...!!");
		
	}
	
	@Override
	public String removeProductfromCart(RemoveProductFromCartRequestDto removeProductFromCartRequestDto) {
		
		addProductRepostory.deleteById(getCartIdByUserNameAndProductId(removeProductFromCartRequestDto) );
		
		return "SUCCESS";
	}

	private Integer getCartIdByUserNameAndProductId(RemoveProductFromCartRequestDto removeProductFromCartRequestDto) {
		
		UserCartMas cartMas=addProductRepostory.findByUserIdAndProductId(removeProductFromCartRequestDto.getUserId(),removeProductFromCartRequestDto.getProductId());
		
		
		return cartMas.getCartId();
	}

}
