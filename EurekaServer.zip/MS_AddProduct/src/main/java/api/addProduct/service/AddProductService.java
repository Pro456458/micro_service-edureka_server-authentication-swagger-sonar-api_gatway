package api.addProduct.service;

import api.addProduct.dto.AddProductRequestDto;
import api.addProduct.dto.AddProductResponseDto;
import api.addProduct.dto.RemoveProductFromCartRequestDto;


public interface AddProductService {

	AddProductResponseDto addProduct(AddProductRequestDto addProductRequestDto);

	String removeProductfromCart(RemoveProductFromCartRequestDto removeProductFromCartRequestDto);

}
