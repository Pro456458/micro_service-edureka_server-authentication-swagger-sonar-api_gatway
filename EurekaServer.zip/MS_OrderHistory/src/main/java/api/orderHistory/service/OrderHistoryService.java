/**
 * 
 */
package api.orderHistory.service;

import java.util.List;

import api.orderHistory.dto.OrderListResponseDto;

/**
 * @author Administrator
 *
 */
public interface OrderHistoryService {

	List<OrderListResponseDto> getOrderHistory(String user_id);

}
