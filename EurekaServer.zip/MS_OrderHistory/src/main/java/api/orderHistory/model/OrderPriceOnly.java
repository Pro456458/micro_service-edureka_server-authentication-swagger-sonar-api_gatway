/**
 * 
 */
package api.orderHistory.model;

/**
 * @author Administrator
 *
 */
public interface OrderPriceOnly {
	
	double getPrice();

}
