package api.orderHistory.exception;

public class ProductNotAvailable extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */

	public ProductNotAvailable() {
		super("The product Not Available");
	}

	public ProductNotAvailable(String msg) {
		super(msg);
	}

	public ProductNotAvailable(String msg, Throwable cause) {
		super(msg, cause);
	}
}
