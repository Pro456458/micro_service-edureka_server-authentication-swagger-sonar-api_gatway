package api.orderHistory.exception;

public class DuplicateEntryException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */

	public DuplicateEntryException() {
		super("This record is already being used");
	}

	public DuplicateEntryException(String msg) {
		super(msg);
	}

	public DuplicateEntryException(String msg, Throwable cause) {
		super(msg, cause);
	}

}
