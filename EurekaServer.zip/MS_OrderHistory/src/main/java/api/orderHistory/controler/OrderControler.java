/**
 * 
 */
package api.orderHistory.controler;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import api.orderHistory.dto.OrderListResponseDto;
import api.orderHistory.service.OrderHistoryService;

/**
 * @author Administrator
 *
 */
@RestController
public class OrderControler {
	
	@Autowired
	OrderHistoryService orderHistoryService;
			//Return a user order History by id
	@RequestMapping(path = "api/order/orderHistory/{user_id}",method = RequestMethod.GET)
	private ResponseEntity<List<OrderListResponseDto>> orderHistory(@PathVariable String user_id) {
		
		return ResponseEntity.ok(orderHistoryService.getOrderHistory(user_id));
	}
}
