package api.orderHistory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class MsOrderHistoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsOrderHistoryApplication.class, args);
	}

}
