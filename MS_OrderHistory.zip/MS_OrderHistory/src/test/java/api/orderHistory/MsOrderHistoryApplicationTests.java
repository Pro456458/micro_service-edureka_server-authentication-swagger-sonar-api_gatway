package api.orderHistory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsOrderHistoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
