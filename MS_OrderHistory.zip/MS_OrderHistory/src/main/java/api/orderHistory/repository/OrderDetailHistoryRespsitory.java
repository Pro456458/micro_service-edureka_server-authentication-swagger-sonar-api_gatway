/**
 * 
 */
package api.orderHistory.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import api.orderHistory.model.OrderDetailMas;
import api.orderHistory.model.OrderPriceOnly;

/**
 * @author Administrator
 *
 */
public interface OrderDetailHistoryRespsitory extends JpaRepository<OrderDetailMas, Integer> {
	
	List<OrderDetailMas> findByProductId(Integer productId);
	List<OrderPriceOnly> findAllByProductId(Integer productId);
	List<OrderPriceOnly> findAllByProductIdIn(List<Integer> productIdList);
	
}
