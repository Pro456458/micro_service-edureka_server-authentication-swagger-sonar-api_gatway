/**
 * 
 */
package api.orderHistory.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import api.orderHistory.model.OrderMas;
import api.orderHistory.model.TotalPriceOnly;

/**
 * @author Administrator
 *
 */
public interface OrderHistoryRespsitory extends JpaRepository<OrderMas, Integer>{
	
	List<OrderMas>  findByUserId(int user_id);
	List<TotalPriceOnly> findAllByUserId(int user_id);
	
	
		
	

}




