package api.orderHistory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsOrderHistoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsOrderHistoryApplication.class, args);
	}

}
