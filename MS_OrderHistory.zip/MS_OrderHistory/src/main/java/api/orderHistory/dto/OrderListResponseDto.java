/**
 * 
 */
package api.orderHistory.dto;

import java.util.List;

import api.orderHistory.model.OrderDetailMas;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * @author Administrator
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class OrderListResponseDto {
	
	 private int orderId;
	 private double totalPrice;
	 private List<OrderDetailMas> orderDetail;

}
