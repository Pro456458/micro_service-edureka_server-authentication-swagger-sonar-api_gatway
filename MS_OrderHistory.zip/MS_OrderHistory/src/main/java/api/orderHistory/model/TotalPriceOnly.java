/**
 * 
 */
package api.orderHistory.model;

/**
 * @author Administrator
 *
 */
/** 
 * Interface-based Projections 
 **/
public interface TotalPriceOnly {
	double getTotalPrice();
}
