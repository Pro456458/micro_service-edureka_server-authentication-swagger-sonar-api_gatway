/**
 * 
 */
package api.orderHistory.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * @author Administrator
 *
 */
@Entity(name = "order_details")
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class OrderDetailMas {
	
	
	@Id
//	@SequenceGenerator(name="order_details_order_details_id_seq",sequenceName="order_details_order_details_id_seq", allocationSize=1)
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="order_details_order_details_id_seq")
	@GeneratedValue
	private int order_details_id;
	
 	
//  private int order_id;
	@Column(name = "product_id")
    private int productId;
	@Column(name = "quantity")
    private int quantity;
	@Column(name = "price")
    private int price;
    
    
    
    
    

}
