/**
 * 
 */
package api.orderHistory.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import api.orderHistory.exception.ObjectNotFoundException;
import api.orderHistory.dto.OrderListResponseDto;
import api.orderHistory.model.OrderMas;
import api.orderHistory.model.TotalPriceOnly;
import api.orderHistory.repository.OrderHistoryRespsitory;
import api.orderHistory.service.OrderHistoryService;

/**
 * @author Administrator
 *
 */
@Service
public class OrderHistoryServiceImpl implements OrderHistoryService {

	@Autowired
	OrderHistoryRespsitory orderHistoryRespsitory;
	
	@Override
	public List<OrderListResponseDto> getOrderHistory(String user_id) {
		
		List<OrderMas> orderHistoryList=orderHistoryRespsitory.findByUserId(Integer.parseInt(user_id));
		
		List<TotalPriceOnly> list=orderHistoryRespsitory.findAllByUserId(Integer.parseInt(user_id));
		
		list.forEach( e -> System.out.println(e.getTotalPrice()));
		if(!orderHistoryList.isEmpty()) {
			return getOrderHistoryDetail(orderHistoryList);	
		}else
		{
			throw new  ObjectNotFoundException("No Record Found With this UserId :"+user_id+ " !!!!!!");
		}
	
		
		
	}
	
	private List<OrderListResponseDto> getOrderHistoryDetail(List<OrderMas> orderHistoryList){
		
		List<OrderListResponseDto> allOrderHistoryList=new ArrayList<OrderListResponseDto>();
		
		try {
			
			orderHistoryList.forEach( orderHistory -> {
				OrderListResponseDto orderListResponseDto=new OrderListResponseDto();
		//		System.out.println(orderHistory.toString());
				orderListResponseDto.setOrderId(orderHistory.getOrderId());
				orderListResponseDto.setTotalPrice(orderHistory.getTotalPrice());
				orderListResponseDto.setOrderDetail(orderHistory.getOrderDetail());
				allOrderHistoryList.add(orderListResponseDto);
			});
			
			
		} catch (NoSuchElementException e) {
			throw new ObjectNotFoundException();
		}
		
		return allOrderHistoryList;
		
	}
	
	
}
