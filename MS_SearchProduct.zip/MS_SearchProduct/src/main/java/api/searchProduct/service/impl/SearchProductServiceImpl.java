/**
 * 
 */
package api.searchProduct.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import api.searchProduct.exception.ObjectNotFoundException;
import api.searchProduct.dto.SearchProductRequestDto;
import api.searchProduct.dto.SearchProductResponseDto;
import api.searchProduct.model.ProductMas;
import api.searchProduct.repository.SearchProductRepository;
import api.searchProduct.service.SearchProductService;

/**
 * @author Administrator
 *
 */
@Service
public class SearchProductServiceImpl implements SearchProductService {
	
	@Autowired
	SearchProductRepository searchProductRepository;
	
	@Autowired
	EntityManagerFactory emf;
	
	

	@Override
	public List<ProductMas> searchProduct() throws Exception {
		// TODO Auto-generated method stub
		return searchProductRepository.findAll();
	}

	@Override
	public List<ProductMas> searchProduct(int product_id)  {
		// TODO Auto-generated method stub
		
		ArrayList<Integer> arrayList=new ArrayList<>();
		arrayList.add(product_id);
		List<ProductMas> productList=new ArrayList<>();
		productList=searchProductRepository.findAllById(arrayList);
		if(!productList.isEmpty()) {
			return productList;
		}else {
			throw new ObjectNotFoundException("No product Details Found of ProductId:"+product_id);
		}
		
	}
	
	@Override
	public List<SearchProductResponseDto> searchProductByProductNameOrProductType(SearchProductRequestDto searchProductRequestDto) {
		
		
		List<SearchProductResponseDto> searchProductResponseDtoList=new ArrayList<>();
		
		if(searchProductRequestDto.getProduct_name()!=null && searchProductRequestDto.getProduct_type()!=null)		
			searchProductResponseDtoList=searchProductByEntityManager(searchProductRequestDto);
		
		else if(searchProductRequestDto.getProduct_name()!=null)
			searchProductResponseDtoList=getAllSearchProductByProductName(searchProductRequestDto.getProduct_name());
		
		else if(searchProductRequestDto.getProduct_type()!=null)
			searchProductResponseDtoList=getAllSearchProductByCategoryName(searchProductRequestDto.getProduct_type());
		
		
		if(!searchProductResponseDtoList.isEmpty()) {
			return searchProductResponseDtoList;
		}else {
			throw new ObjectNotFoundException("No product Details Found  !!!!");
		}
	}
	
	private List<SearchProductResponseDto> searchProductByEntityManager(SearchProductRequestDto searchProductRequestDto){
		
		
		EntityManager em=emf.createEntityManager();
		
		StringBuilder builder=new StringBuilder()
				.append("SELECT pm.productName,cm.category_name FROM product_master pm,category_master cm WHERE pm.categoryId=cm.category_id AND pm.productName='")
				.append(searchProductRequestDto.getProduct_name()).append("' OR ")
				.append("cm.category_name='")
				.append(searchProductRequestDto.getProduct_type())
				.append("'");
		
		Query query=em.createQuery(builder.toString());
		
		
		@SuppressWarnings("unchecked")
		List<Object[]> rows=query.getResultList();
		
		em.close();
		
		List<SearchProductResponseDto> searchProductResponseDtoList=new ArrayList<>(rows.size());
		rows.forEach(  productMasList ->{ searchProductResponseDtoList.add( new SearchProductResponseDto((String) productMasList[0], (String) productMasList[1]) ); } );
		
		return searchProductResponseDtoList;
		
	}
	
	
	private List<SearchProductResponseDto> getAllSearchProductByProductName(String product_name){
		
		List<ProductMas> searchProductList= searchProductRepository.searchProductByProductName(product_name);
		//searchProductList.forEach(e-> System.out.println(e.toString()));
		
		List<SearchProductResponseDto> searchProductResponseDtoList=new ArrayList<>(searchProductList.size());
		
		searchProductList.forEach(  productMasList ->{ searchProductResponseDtoList.add( new SearchProductResponseDto(productMasList.getProductName(),productMasList.getCategoryMas().getCategory_name())); } );
				
		return searchProductResponseDtoList;
		
	}
	
	private List<SearchProductResponseDto> getAllSearchProductByCategoryName(String category_name){
		
		
		List<ProductMas> searchProductList= searchProductRepository.searchProductByCategoryName(category_name);
		//searchProductList.forEach(e-> System.out.println(e.toString()));
		
		List<SearchProductResponseDto> searchProductResponseDtoList=new ArrayList<>(searchProductList.size());
		
		searchProductList.forEach(  productMasList ->{ searchProductResponseDtoList.add( new SearchProductResponseDto(productMasList.getProductName(),productMasList.getCategoryMas().getCategory_name())); } );
				
		return searchProductResponseDtoList;
		
	}	
	

}
