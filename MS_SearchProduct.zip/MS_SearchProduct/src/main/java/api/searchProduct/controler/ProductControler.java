/**
 * 
 */
package api.searchProduct.controler;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import api.searchProduct.dto.SearchProductRequestDto;
import api.searchProduct.dto.SearchProductResponseDto;
import api.searchProduct.model.ProductMas;
import api.searchProduct.service.SearchProductService;

/**
 * @author Administrator
 *
 */
@RestController
public class ProductControler {


	@Autowired
	SearchProductService searchProductService=null;


	@RequestMapping(path = "/api/product/searchProduct/{product_id}", method = RequestMethod.POST)
	private ResponseEntity<List<ProductMas>> searchProduct(@PathVariable int product_id) {
		
			return ResponseEntity.ok(searchProductService.searchProduct(product_id));

	}

	
	@RequestMapping(path = "/api/product/searchProduct", method = RequestMethod.POST)
	private ResponseEntity<List<SearchProductResponseDto>> searchProductByProductNameOrProductType(@RequestBody SearchProductRequestDto searchProductRequestDto) {

		System.out.println("searchProductRequest: "+searchProductRequestDto.toString());

		return ResponseEntity.ok(searchProductService.searchProductByProductNameOrProductType(searchProductRequestDto));

		
	}




	
	
 

}
